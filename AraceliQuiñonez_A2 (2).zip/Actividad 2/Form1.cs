﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void saludoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.frmSaludo frmSaludo = new Formularios.frmSaludo();
            frmSaludo.Show();
        }

        private void datosPersonalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.frmDatosPersonales frmDatosPersonales = new Formularios.frmDatosPersonales();
            frmDatosPersonales.Show();
        }

        private void operacionesBásicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.frmOperacionesBasicas frmOperacionesBasicas = new Formularios.frmOperacionesBasicas();
            frmOperacionesBasicas.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
