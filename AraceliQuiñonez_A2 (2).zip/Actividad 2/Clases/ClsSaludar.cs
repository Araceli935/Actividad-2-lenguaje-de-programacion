﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_2.Clases
{
    public class ClsSaludar
    {
        public string Saludar(string Nombre)
        {
            string saludo;
            saludo = "Hola " +Nombre + " ¿Qué tal va tu día?";
            return saludo;
        }
    }
}
