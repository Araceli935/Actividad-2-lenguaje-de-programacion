﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_2.Clases
{
    public class clsOperaciones
    {
        public double Sumar(double num1, double num2, double num3, double num4, double num5, double num6)
        {
            double resultado;
            resultado = num1 + num2 + num3 + num4 + num5 + num6;
            return resultado;
        }

        public double Restar(double num1, double num2, double num3, double num4, double num5, double num6)
        {
            double resultado;
            resultado = num1 + num2 + num3 - num4 - num5 - num6;
            return resultado;
        }

        public double Multiplicar(double num1, double num2, double num3, double num4, double num5, double num6)
        {
            double resultado;
            resultado = (num1 + num2 + num3) * (num4 + num5 + num6);
            return resultado;
        }

        public double Dividir(double num1, double num2, double num3, double num4, double num5, double num6)
        {
            double resultado;
            resultado = (num1 + num2 + num3) / (num4 + num5 + num6);
            return resultado;
        }

    }
}
