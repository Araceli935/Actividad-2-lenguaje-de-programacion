﻿using Actividad_2.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2.Formularios
{
    public partial class frmOperacionesBasicas : Form
    {
        public frmOperacionesBasicas()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double resultado;
            Clases.clsOperaciones clsOperaciones = new clsOperaciones();

            if (txtN1.Text == "") { txtN1.Text = "0"; }
            if (txtN2.Text == "") { txtN2.Text = "0"; }
            if (txtN3.Text == "") { txtN3.Text = "0"; }
            if (txtN4.Text == "") { txtN4.Text = "0"; }
            if (txtN5.Text == "") { txtN5.Text = "0"; }
            if (txtN6.Text == "") { txtN6.Text = "0"; }

            resultado = clsOperaciones.Sumar(double.Parse(txtN1.Text), double.Parse(txtN2.Text), double.Parse(txtN3.Text), 
            double.Parse(txtN4.Text), double.Parse(txtN5.Text), double.Parse(txtN6.Text));
            txtResultado.Text= resultado.ToString();
            txtOperador.Text = "+";
        }

        private void btnRestar_Click(object sender, EventArgs e)
        {
            double resultado;
            Clases.clsOperaciones clsOperaciones = new clsOperaciones();

            if (txtN1.Text == "") { txtN1.Text = "0"; }
            if (txtN2.Text == "") { txtN2.Text = "0"; }
            if (txtN3.Text == "") { txtN3.Text = "0"; }
            if (txtN4.Text == "") { txtN4.Text = "0"; }
            if (txtN5.Text == "") { txtN5.Text = "0"; }
            if (txtN6.Text == "") { txtN6.Text = "0"; }

            resultado = clsOperaciones.Restar(double.Parse(txtN1.Text), double.Parse(txtN2.Text), double.Parse(txtN3.Text),
            double.Parse(txtN4.Text), double.Parse(txtN5.Text), double.Parse(txtN6.Text));
            txtResultado.Text = resultado.ToString();
            txtOperador.Text = "-";
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            double resultado;
            Clases.clsOperaciones clsOperaciones = new clsOperaciones();

            if (txtN1.Text == "") { txtN1.Text = "0"; }
            if (txtN2.Text == "") { txtN2.Text = "0"; }
            if (txtN3.Text == "") { txtN3.Text = "0"; }
            if (txtN4.Text == "") { txtN4.Text = "0"; }
            if (txtN5.Text == "") { txtN5.Text = "0"; }
            if (txtN6.Text == "") { txtN6.Text = "0"; }

            resultado = clsOperaciones.Multiplicar(double.Parse(txtN1.Text), double.Parse(txtN2.Text), double.Parse(txtN3.Text),
            double.Parse(txtN4.Text), double.Parse(txtN5.Text), double.Parse(txtN6.Text));
            txtResultado.Text = resultado.ToString();
            txtOperador.Text = "*";
        }

        private void btnDivision_Click(object sender, EventArgs e)
        {
            double resultado;
            Clases.clsOperaciones clsOperaciones = new clsOperaciones();

            if (txtN1.Text == "") { txtN1.Text = "0"; }
            if (txtN2.Text == "") { txtN2.Text = "0"; }
            if (txtN3.Text == "") { txtN3.Text = "0"; }
            if (txtN4.Text == "") { txtN4.Text = "0"; }
            if (txtN5.Text == "") { txtN5.Text = "0"; }
            if (txtN6.Text == "") { txtN6.Text = "0"; }

            resultado = clsOperaciones.Dividir(double.Parse(txtN1.Text), double.Parse(txtN2.Text), double.Parse(txtN3.Text),
            double.Parse(txtN4.Text), double.Parse(txtN5.Text), double.Parse(txtN6.Text));
            txtResultado.Text = resultado.ToString();
            txtOperador.Text = "/";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtN1.Clear(); 
            txtN2.Clear(); 
            txtN3.Clear(); 
            txtN4.Clear(); 
            txtN5.Clear(); 
            txtN6.Clear(); 
            txtOperador.Clear();
            txtResultado.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
