﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2.Formularios
{
    public partial class frmIngreso : Form
    {
        public frmIngreso()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if(txtClave.Text=="")
            {
                MessageBox.Show("Debe Ingresar la contraseña");
            }
            else if(txtClave.Text=="Clave123*")
            {
                frmMenu frmMenu = new frmMenu();
                frmMenu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Contraseña incorrecta ");
                txtClave.Clear();
            }
        }
    }
}
